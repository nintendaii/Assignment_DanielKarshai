﻿namespace Module.Project.Servers {
    public static class ServerConstants {
        public const int HttpTimeoutSeconds = 600;
        public const string ApplicationFormUrlencodedValue = "application/x-www-form-urlencoded";
        public const string ApplicationJsonKey = "accept";
        public const string ApplicationJsonValue = "application/json";
        public const string ApplicationJsonWithUtf8Value = "application/json; charset=UTF-8";
        public const string AuthorizationKey = "Authorization";
        public const string AuthorizationBasicValue = "Basic";
        public const string AuthorizationBearerValue = "Bearer";
        public const string AssetFileAttachmentTypeImagePng = "image/png";
        public const string ContentTypeKey = "Content-Type";
    }
}