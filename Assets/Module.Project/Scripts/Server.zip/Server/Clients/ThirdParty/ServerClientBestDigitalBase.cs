﻿using System.Net.Http.Headers;
using Module.Project.Managers;
using Module.Project.Servers.RequestResponse;
using Zenject;

namespace Module.Project.Servers {
    public abstract class ServerClientBestDigitalBase<TRequest, TResponse> : ServerClientBestBase<TRequest, TResponse> where TRequest : RequestBase {
        [Inject] private readonly ManagerDigitalAccount managerDigitalAccount;

        public override void Initialize() {
            AuthorizationToken = new AuthenticationHeaderValue(ServerConstants.AuthorizationBearerValue, managerDigitalAccount.AuthorizationToken);
        }
    }
}
