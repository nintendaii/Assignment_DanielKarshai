﻿using System;
using Module.Project.Servers.RequestResponse;

namespace Module.Project.Servers {
    public class ServerClientBestDigitalPutGameResults : ServerClientBestDigitalBase<RequestResults, ResponseResults> {
        public void Send(RequestResults request, string gameId) {
            var uri = new UriBuilder(ServerSettings.ApiDigitalUniverseUrl + ServerSettings.Game + ServerSettings.ResultsId + gameId);
            Put(uri.Uri, request);
        }
    }
}
