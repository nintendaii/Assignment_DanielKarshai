using System;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using BestHTTP;
using Module.Core.MVC;
using Newtonsoft.Json;

namespace Module.Project.Servers {
    public struct RequestHeaderContent {
        public string Key;
        public string Value;

        public RequestHeaderContent(string key, string value) {
            Key = key;
            Value = value;
        }
    }

    public class ServerBestBase : ControllerBase {
        public event Action<HTTPResponse> SuccessAction;
        public event Action<HTTPResponse> ErrorAction;
        
        public event Action<HTTPRequest> RequestAction;
        public event Action<string> RequestStringAction;
        public event Action<string> ResponseStringAction;
        public event Action<string> ErrorResponseStringAction;
        
        private readonly TimeSpan timeout = TimeSpan.FromSeconds(ServerConstants.HttpTimeoutSeconds);

        protected void Send<TRequest>(HTTPMethods httpMethod, Uri uri, TRequest requestBase, AuthenticationHeaderValue authorizationToken, params RequestHeaderContent[] requestHeaderContents) {
            var httpRequest = new HTTPRequest(uri, httpMethod, (request, response) => {
                if (request != null) {
                    var requestBody = request.GetEntityBody();
                    if (requestBody != null) {
                        RequestStringAction?.Invoke(Encoding.UTF8.GetString(request.GetEntityBody()));
                    }

                    RequestAction?.Invoke(request);
                }

                if (response != null) {
                    if (response.IsSuccess) {
                        ResponseStringAction?.Invoke(response.DataAsText);
                        SuccessAction?.Invoke(response);
                    } else {
                        ErrorResponseStringAction?.Invoke(response.DataAsText);
                        ErrorAction?.Invoke(response);
                    }
                }
            });
            
            httpRequest.SetHeader(ServerConstants.AuthorizationKey, authorizationToken?.ToString());
            
            foreach (var requestHeaderContent in requestHeaderContents ?? Enumerable.Empty<RequestHeaderContent>()) {
                httpRequest.AddHeader(requestHeaderContent.Key, requestHeaderContent.Value);
            }
            
            if (requestBase != null) {
                httpRequest.AddHeader(ServerConstants.ContentTypeKey, ServerConstants.ApplicationJsonWithUtf8Value);
                httpRequest.RawData = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(requestBase));
            }

            httpRequest.Timeout = timeout;
            
            httpRequest.Send();
        }
    }
}