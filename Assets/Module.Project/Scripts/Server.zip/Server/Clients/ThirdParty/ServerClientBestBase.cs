﻿using System;
using System.Net.Http.Headers;
using BestHTTP;
using Newtonsoft.Json;

namespace Module.Project.Servers {
    public abstract class ServerClientBestBase<TRequest, TResponse> : ServerBestBase {
        public event Action<TRequest> RequestDataAction;
        public event Action<TResponse> ResponseDataAction;
        public event Action<TResponse> ErrorResponseDataAction;

        protected virtual AuthenticationHeaderValue AuthorizationToken { get; set; }

        protected void Put(Uri uri, TRequest requestBase, params RequestHeaderContent[] requestHeaderContents) => ActionAndSend(HTTPMethods.Put, uri, requestBase, AuthorizationToken, requestHeaderContents);
        protected void Post(Uri uri, TRequest requestBase, params RequestHeaderContent[] requestHeaderContents) => ActionAndSend(HTTPMethods.Post, uri, requestBase, AuthorizationToken, requestHeaderContents);
        protected void Get(Uri uri, TRequest requestBase, params RequestHeaderContent[] requestHeaderContents) => ActionAndSend(HTTPMethods.Get, uri, requestBase, AuthorizationToken, requestHeaderContents);
        protected void Delete(Uri uri, TRequest requestBase, params RequestHeaderContent[] requestHeaderContents) => ActionAndSend(HTTPMethods.Delete, uri, requestBase, AuthorizationToken, requestHeaderContents);

        private void ActionAndSend(HTTPMethods httpMethod, Uri uri, TRequest requestBase, AuthenticationHeaderValue authorizationToken, params RequestHeaderContent[] requestHeaderContents) {
            RequestStringAction += request => RequestDataAction?.Invoke(JsonConvert.DeserializeObject<TRequest>(request));
            ResponseStringAction += response => ResponseDataAction?.Invoke(JsonConvert.DeserializeObject<TResponse>(response));
            ErrorResponseStringAction += response => ErrorResponseDataAction?.Invoke(JsonConvert.DeserializeObject<TResponse>(response));
            Send(httpMethod, uri, requestBase, authorizationToken, requestHeaderContents);
        }
    }
}
