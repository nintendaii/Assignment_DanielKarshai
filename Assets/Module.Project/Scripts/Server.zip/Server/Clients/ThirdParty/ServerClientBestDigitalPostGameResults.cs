﻿using System;
using Module.Project.Servers.RequestResponse;

namespace Module.Project.Servers {
    public class ServerClientBestDigitalPostGameResults : ServerClientBestDigitalBase<RequestGame, ResponseGame> {
        public void Send(RequestGame request) {
            var uri = new UriBuilder(ServerSettings.ApiDigitalUniverseUrl + ServerSettings.Game + ServerSettings.Results);
            Post(uri.Uri, request);
        }
    }
}
