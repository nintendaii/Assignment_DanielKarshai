﻿using System;
using Module.Project.Servers.RequestResponse;

namespace Module.Project.Servers {
    public class ServerClientBestDigitalGetUserStatus : ServerClientBestDigitalBase<RequestBase, ResponseBase> {
        public void Send(string userId) {
            var uri = new UriBuilder(ServerSettings.ApiDigitalUniverseUrl + ServerSettings.Users + ServerSettings.ValidId + userId);
            Get(uri.Uri, null);
        }
    }
}
