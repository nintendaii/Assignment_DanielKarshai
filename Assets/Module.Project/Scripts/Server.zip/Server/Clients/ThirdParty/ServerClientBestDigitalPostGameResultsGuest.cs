﻿using System;
using System.Web;
using Module.Project.Servers.RequestResponse;

namespace Module.Project.Servers {
    public class ServerClientBestDigitalPostGameResultsGuest : ServerClientBestDigitalBase<RequestGameGuest, ResponseGame> {
        public void Send(RequestGameGuest request) {
            var uri = new UriBuilder(ServerSettings.ApiDigitalUniverseUrl + ServerSettings.Game + ServerSettings.Results);
            var paramValues = HttpUtility.ParseQueryString(uri.Query);
            paramValues.Add(ServerSettings.QueryType, ServerSettings.QueryTypeValueGuest);
            uri.Query = paramValues.ToString();
            Post(uri.Uri, request);
        }
    }
}
