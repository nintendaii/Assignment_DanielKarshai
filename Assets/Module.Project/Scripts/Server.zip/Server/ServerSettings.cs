﻿namespace Module.Project.Servers {
    public static class ServerSettings {
        public const string ApiDigitalUniverseUrl = "https://digital-universe.herokuapp.com";
        
        public const string Users = "/users";
        
        public const string Play = "/play";
        public static readonly string PlayId = Play + PathSeparator;
        
        public const string Game = "/game";
        
        public const string Results = "/results";
        public static readonly string ResultsId = Results + PathSeparator;

        public const string Valid = "/valid";
        public static readonly string ValidId = Valid + PathSeparator;

        public const char PathSeparator = '/';

        public const string QueryId = "id";
        public const string QueryType = "type";
        public const string QueryTypeValueGuest = "guest";
    }
}