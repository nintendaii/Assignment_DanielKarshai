﻿using System;
using Newtonsoft.Json;

namespace Module.Project.Servers.RequestResponse {
    #region Request

    public class RequestGame : RequestBase {
        [JsonProperty("student")] public string StudentId;
        [JsonProperty("story")] public string StoryId;
        [JsonProperty("type")] public string LoginType;
    }
    
    public class RequestGameGuest : RequestBase {
        [JsonProperty("uId")] public string UId;
        [JsonProperty("story")] public string StoryId;
    }
    
    public class RequestResults : RequestBase {
        [JsonProperty("result")] public string GameResult;
    }
    
    #endregion

    #region Response

    public class ResponseGame : ResponseBase {
        [JsonProperty("id")] public string GameId;
        [JsonProperty("student")] public string StudentId;
        [JsonProperty("uId")] public string UId;
        [JsonProperty("story")] public string StoryId;
        [JsonProperty("createdAt")] public DateTime CreatedAt;
        [JsonProperty("updatedAt")] public DateTime UpdatedAt;
    }
    
    public class ResponseResults : ResponseBase {
        [JsonProperty("id")] public string GameId;
        [JsonProperty("student")] public string StudentId;
        [JsonProperty("story")] public string StoryId;
        [JsonProperty("result")] public string GameResult;
        [JsonProperty("createdAt")] public DateTime CreatedAt;
        [JsonProperty("updatedAt")] public DateTime UpdatedAt;
    }

    #endregion
}
