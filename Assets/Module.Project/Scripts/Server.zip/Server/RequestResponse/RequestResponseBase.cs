﻿namespace Module.Project.Servers.RequestResponse {
    public abstract class RequestResponseBase { }

    #region Request

    public abstract class RequestBase : RequestResponseBase { }

    #endregion

    #region Response

    public abstract class ResponseBase : RequestResponseBase { }

    #endregion
}
