﻿using Newtonsoft.Json;

namespace Module.Project.Servers.RequestResponse {
    #region Request

    public class RequestLogin : RequestBase {
        [JsonProperty("user_id")] public string UserId;
    }
    
    #endregion

    #region Response

    public class ResponseLogin : ResponseBase {
        [JsonProperty("user_id")] public string UserId;
        [JsonProperty("token")] public string Token;
    }

    #endregion
}
